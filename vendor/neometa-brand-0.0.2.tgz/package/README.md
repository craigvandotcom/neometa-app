# @neometa/brand

The shared brand system for neoMeta — design tokens, Tailwind preset, and voice guidelines consumed by every app and marketing site in the portfolio.

**Status:** v0 / alpha — tokens stabilizing, not yet published to npm.

---

## What this is

A small TypeScript package that packages neoMeta's brand decisions as code:

- **Pillar colors** — green (eat), blue (move), yellow (meditate), red (signal)
- **Neutrals** — warm off-white, charcoal scale, dark-mode surfaces
- **Typography** — DM Serif Display (display) + General Sans (body)
- **Spacing & radius scale**
- **Motion tokens** — easing curves, durations
- **Tailwind preset** — drop into any consumer site

The strategic anchor for everything in this repo — pillars, voice rules, anti-patterns, per-app expression — lives in the **`brand-system` skill** at `software/.claude/skills/brand-system/`. Agents working in any neoMeta app auto-invoke it; humans can read `software/.claude/skills/brand-system/reference/brand-system.md` directly.

This package ships the *runtime* layer (tokens-as-code, Tailwind preset). The skill ships the *authoring* layer (brand identity, voice rules, anti-patterns). If they ever conflict, this package wins for runtime values.

---

## Repo structure

```
neometa-brand/
├── README.md             # This file
├── tokens/
│   ├── colors.ts         # Pillar colors, neutrals, semantic tokens
│   ├── typography.ts     # Font families, scale, weights
│   ├── spacing.ts        # Spacing & radius scales
│   └── motion.ts         # Easing curves, durations
├── tailwind/
│   └── preset.ts         # Tailwind preset consuming tokens
├── examples/
│   └── basic.astro       # Minimal consumer example
└── package.json
```

---

## Consuming the system (planned, post-publish)

```ts
// tailwind.config.ts
import { neoMetaPreset } from '@neometa/brand/tailwind'

export default {
  presets: [neoMetaPreset],
  // ...
}
```

```ts
// Direct token access
import { pillarColors, neutrals } from '@neometa/brand/tokens'
```

---

## Apps that consume this

| App | Domain | Pillar | Surface |
|---|---|---|---|
| Body Compass | bodycompass.app | Eat (green) | Dark |
| Unsit | unsit.app | Move (blue) | Light |
| Move Free | movefreedom.app | Move (blue) | Light |
| Art Still | artstill.app | Meditate (yellow) | Dark |
| neoMeta umbrella | neometa.app | All four (introducer only) | Light |

---

## License

MIT © Craig van Heerden
