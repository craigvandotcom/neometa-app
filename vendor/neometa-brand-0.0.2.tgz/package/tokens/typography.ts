/**
 * neoMeta typography tokens
 *
 * Display: DM Serif Display (Google Fonts) — humanist warmth, reserved for hero
 *          headings and emotional moments. Already established in Body Compass.
 * Body:    General Sans (Indian Type Foundry, free) — distinctive geometric
 *          sans without trend-coding. Replaces system-only fallback used in
 *          Unsit's current build.
 *
 * Loading guidance for consumers:
 *   - DM Serif Display: Google Fonts (https://fonts.google.com/specimen/DM+Serif+Display)
 *   - General Sans: https://fonts.indiantypefoundry.com/general-sans (self-host)
 */

export const fontFamilies = {
  display: ['DM Serif Display', 'Georgia', 'serif'],
  body: [
    'General Sans',
    '-apple-system',
    'BlinkMacSystemFont',
    'Segoe UI',
    'Roboto',
    'sans-serif',
  ],
} as const

/** Type scale (modular, ratio ~1.25). Hierarchy via weight + scale + space. */
export const fontSizes = {
  xs: '0.75rem',   // 12px — microcopy
  sm: '0.875rem',  // 14px — UI labels
  base: '1rem',    // 16px — body
  lg: '1.125rem',  // 18px — emphasis body
  xl: '1.25rem',   // 20px — subhead
  '2xl': '1.5rem', // 24px — section head (UI)
  '3xl': '1.875rem', // 30px — section head (marketing)
  '4xl': '2.375rem', // 38px — hero subhead
  '5xl': '3rem',     // 48px — hero
  '6xl': '3.75rem',  // 60px — display
  '7xl': '4.75rem',  // 76px — display large
} as const

export const fontWeights = {
  light: '300',
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
} as const

export const lineHeights = {
  tight: '1.1',
  snug: '1.25',
  normal: '1.5',
  relaxed: '1.625',
  loose: '1.75',
} as const

export const letterSpacing = {
  tighter: '-0.04em',
  tight: '-0.02em',
  normal: '0',
  wide: '0.02em',
  wider: '0.04em',
} as const
