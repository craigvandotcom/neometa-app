/**
 * neoMeta color tokens
 *
 * Pillar colors map to the eat.move.meditate taxonomy:
 *   - eat (green) → Body Compass
 *   - move (blue) → Unsit, Move Free
 *   - meditate (yellow/gold) → Art Still
 *
 * Signal red is system-wide for warnings/errors only — not a pillar.
 *
 * Each pillar has a 50–950 scale anchored at 500. The 500 step matches the
 * canonical hex listed in brand-system.md §2.
 */

export const pillars = {
  /** Eat — green. Anchor: #11b88a (Body Compass primary, established) */
  eat: {
    50: '#e6faf2',
    100: '#c2f1de',
    200: '#88e3bf',
    300: '#4fd2a1',
    400: '#22c389',
    500: '#11b88a',
    600: '#0e9670',
    700: '#0b7558',
    800: '#0a5a44',
    900: '#08402f',
    950: '#04241b',
  },

  /** Move — blue. Anchor: #1565d8 (close to Unsit's existing primary) */
  move: {
    50: '#ebf2fe',
    100: '#d3e1fc',
    200: '#a8c3f8',
    300: '#7aa3f1',
    400: '#4783e6',
    500: '#1565d8',
    600: '#1152b3',
    700: '#0d408d',
    800: '#0a3068',
    900: '#072143',
    950: '#031326',
  },

  /** Meditate — deep gold. Anchor: #d4a017 (refined for Art Still primary).
   *  Premium-contemplative on dark surface; reads as gold-leaf / dawn / candlelight,
   *  deliberately distinct from BC's brighter zone-yellow signal (see `zones.neutral`). */
  meditate: {
    50: '#fbf6e6',
    100: '#f6e8c2',
    200: '#ecd187',
    300: '#e1b94a',
    400: '#dda82a',
    500: '#d4a017',
    600: '#b3870c',
    700: '#8d6a08',
    800: '#674e06',
    900: '#423204',
    950: '#261c02',
  },

  /** Signal — red. System-wide warnings/errors only. Not a pillar brand color. */
  signal: {
    50: '#fef0ee',
    100: '#fcd9d3',
    200: '#fab1a6',
    300: '#f7867a',
    400: '#f4665a',
    500: '#f25a44',
    600: '#d23d28',
    700: '#a52f1f',
    800: '#7a2117',
    900: '#52150f',
    950: '#2a0a07',
  },
} as const

/**
 * Surface neutrals.
 * Warmer than pure white (avoid clinical-cold), softer than pure black.
 */
export const neutrals = {
  // Light surfaces
  surfaceWarm: '#FAFAF8',
  surfacePaper: '#F5F3EF',

  // Dark surfaces (BC, Art Still)
  surfaceDark: '#0A0A0B',
  surfaceCardDark: '#18181B',

  // Type
  ink: '#1A1A1A',
  inkMuted: '#6B7280',
  inkInverse: '#FAFAF8',

  // Borders
  borderLight: '#E5E7EB',
  borderDark: '#27272A',
} as const

/**
 * Zone tokens — for in-app state signaling (good / caution / bad).
 *
 * Distinct from pillar colors. Body Compass's zone taxonomy (food healing/neutral/hurting)
 * uses these. The neutral zone uses a brighter yellow than the meditate pillar so
 * caution-signaling stays high-contrast and recognizable without polluting Art of
 * Stillness's deeper-gold pillar identity.
 */
export const zones = {
  /** Healing / positive — green, shared with eat-pillar primary */
  positive: pillars.eat[500],
  /** Caution / neutral — bright yellow, distinct from meditate-pillar gold */
  neutral: '#edc33d',
  /** Hurting / warning — red, shared with signal */
  warn: pillars.signal[500],
} as const

/**
 * Semantic aliases — meaning, not appearance.
 * Apps may map these to per-app contexts in their own theme layer.
 */
export const semantic = {
  /** Generic positive/healing */
  positive: zones.positive,
  /** Generic warning/danger */
  warn: zones.warn,
  /** Generic informational accent — usually move-pillar blue */
  info: pillars.move[500],
  /** Generic emphasis / contemplative — meditate-pillar gold */
  emphasis: pillars.meditate[500],
} as const

export type PillarName = keyof typeof pillars
export type PillarScale = keyof typeof pillars.eat
