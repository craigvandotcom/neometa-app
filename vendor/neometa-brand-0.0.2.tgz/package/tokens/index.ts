/**
 * @neometa/brand — token entry point
 *
 * Re-exports all token primitives. Import from `@neometa/brand/tokens` for
 * direct access, or use `@neometa/brand/tailwind` for the Tailwind preset.
 *
 * The strategic anchor for everything in this package is brand-system.md.
 * Read that before changing any token value.
 */

export * from './colors'
export * from './typography'
export * from './spacing'
export * from './motion'
