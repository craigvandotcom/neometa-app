/**
 * neoMeta spacing & radius tokens
 *
 * Base unit: 4px (0.25rem). Generous whitespace is non-negotiable —
 * restraint is the dominant premium signal in this category.
 */

export const spacing = {
  0: '0',
  1: '0.25rem',  // 4px
  2: '0.5rem',   // 8px
  3: '0.75rem',  // 12px
  4: '1rem',     // 16px
  5: '1.25rem',  // 20px
  6: '1.5rem',   // 24px
  8: '2rem',     // 32px
  10: '2.5rem',  // 40px
  12: '3rem',    // 48px
  16: '4rem',    // 64px
  20: '5rem',    // 80px
  24: '6rem',    // 96px
  32: '8rem',    // 128px
} as const

/**
 * Radius scale.
 *   - lg (16px) is the default card radius
 *   - 3xl (48px) is the BC glassmorphism hero pattern — used sparingly
 */
export const radius = {
  none: '0',
  sm: '0.5rem',   // 8px  — inputs, small chips
  md: '0.75rem',  // 12px — buttons, small cards
  lg: '1rem',     // 16px — default cards
  xl: '1.5rem',   // 24px — feature cards
  '2xl': '2rem',  // 32px — section containers
  '3xl': '3rem',  // 48px — glassmorphism hero (BC pattern)
  full: '9999px',
} as const

/** Container max-widths for marketing layouts */
export const containers = {
  prose: '65ch',
  narrow: '768px',
  default: '1280px',
  wide: '1536px',
} as const
