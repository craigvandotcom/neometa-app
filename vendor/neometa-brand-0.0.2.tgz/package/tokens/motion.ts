/**
 * neoMeta motion tokens
 *
 * Restrained micro-interactions. Motion communicates state changes and
 * affordances; it does not announce itself. `prefers-reduced-motion` always
 * respected by consumers.
 */

export const easings = {
  /** Snappy, slightly spring-like. Used in Unsit. Default for buttons and quick UI. */
  snap: 'cubic-bezier(0.21, 0.47, 0.32, 0.98)',
  /** Standard ease-in-out. Default for layout transitions. */
  soft: 'cubic-bezier(0.4, 0, 0.2, 1)',
  linear: 'linear',
} as const

export const durations = {
  fast: '150ms',     // hover, focus
  base: '200ms',     // most transitions
  slow: '300ms',     // card stagger entrance
  deliberate: '500ms', // hero/marketing reveal
} as const
