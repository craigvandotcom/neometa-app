/**
 * @neometa/brand — Tailwind preset
 *
 * Drop into any Tailwind config to inherit the neoMeta brand system:
 *   - Pillar colors (eat / move / meditate / signal)
 *   - Surface neutrals
 *   - Type scale + families
 *   - Spacing & radius
 *   - Motion tokens
 *
 * Usage:
 *   import { neoMetaPreset } from '@neometa/brand/tailwind'
 *   export default { presets: [neoMetaPreset] }
 *
 * Per-app theming: each app overrides `theme.extend.colors.brand` to point at
 * its pillar (e.g. Body Compass: brand → eat). See examples/basic.astro.
 */

import { pillars, neutrals, zones } from '../tokens/colors'
import {
  fontFamilies,
  fontSizes,
  fontWeights,
  lineHeights,
  letterSpacing,
} from '../tokens/typography'
import { spacing, radius, containers } from '../tokens/spacing'
import { easings, durations } from '../tokens/motion'

/**
 * The preset is intentionally typed as a plain object rather than
 * `Partial<tailwindcss.Config>` so the brand package has no peer-import
 * burden at compile time. Tailwind merges presets structurally.
 */
export const neoMetaPreset = {
  theme: {
    extend: {
      colors: {
        // Pillars
        eat: pillars.eat,
        move: pillars.move,
        meditate: pillars.meditate,
        signal: pillars.signal,

        // Zone semantic tokens (in-app state signaling)
        zones: {
          positive: zones.positive,
          neutral: zones.neutral,
          warn: zones.warn,
        },

        // Surface neutrals
        surface: {
          warm: neutrals.surfaceWarm,
          paper: neutrals.surfacePaper,
          dark: neutrals.surfaceDark,
          'card-dark': neutrals.surfaceCardDark,
        },

        ink: {
          DEFAULT: neutrals.ink,
          muted: neutrals.inkMuted,
          inverse: neutrals.inkInverse,
        },

        // Per-app brand alias — overridden in app's tailwind.config to point at its pillar.
        // Default falls back to eat (BC) so the preset is self-contained.
        brand: pillars.eat,
      },

      fontFamily: {
        display: [...fontFamilies.display],
        sans: [...fontFamilies.body],
      },

      fontSize: fontSizes,
      fontWeight: fontWeights,
      lineHeight: lineHeights,
      letterSpacing,

      spacing,
      borderRadius: radius,
      maxWidth: containers,

      transitionTimingFunction: {
        snap: easings.snap,
        soft: easings.soft,
      },

      transitionDuration: {
        fast: durations.fast.replace('ms', ''),
        base: durations.base.replace('ms', ''),
        slow: durations.slow.replace('ms', ''),
        deliberate: durations.deliberate.replace('ms', ''),
      },
    },
  },
}

export default neoMetaPreset
